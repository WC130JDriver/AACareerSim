import React, { useMemo, useState } from "react";
import { Upload, Plus, Copy, Download, Filter, Rocket, Database, Settings } from "lucide-react";
import * as XLSX from "xlsx";
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer, BarChart, Bar } from "recharts";

// --- Minimal utility styles (Tailwind available) ---
const Card = ({ children, className = "" }) => (
  <div className={`rounded-2xl shadow-sm border border-gray-200 bg-white p-4 ${className}`}>{children}</div>
);
const SectionTitle = ({ icon: Icon, children, right }) => (
  <div className="flex items-center justify-between mb-3">
    <div className="flex items-center gap-2">
      {Icon ? <Icon className="w-5 h-5" /> : null}
      <h2 className="text-lg font-semibold">{children}</h2>
    </div>
    {right}
  </div>
);

// ------------------------------ Helpers ------------------------------
function parseDate(v){ const d = new Date(v); return isNaN(d.getTime()) ? null : d; }
function normalizeSeat(s){ if(!s) return s; const t = String(s).toLowerCase(); if(/(^|\b)(ca|captain)\b/.test(t)) return "Captain"; if(/(^|\b)(fo|first\s*officer)\b/.test(t)) return "First Officer"; return s; }
function yyyymm(m){ return `${m.getFullYear()}-${String(m.getMonth()+1).padStart(2,'0')}`; }

// ------------------------------ Roster Ingest ------------------------------
function mapRosterRow(row){
  const mapKey = k => (k ? String(k).trim().toLowerCase() : "");
  const keys = Object.fromEntries(Object.keys(row).map(k => [mapKey(k), k]));
  const get = (...cands) => { for(const c of cands){ if(keys[c]!==undefined) return row[keys[c]]; } return null; };
  const senior = get("senioritynumber","seniority number","seniority");
  const dob = get("dob","date of birth","birth date","yob");
  const doh = get("doh","date of hire","hire date");
  const seat = normalizeSeat(get("seat","position","pos"));
  return {
    senioritynumber: senior!=null ? Number(String(senior).replace(/[^0-9]/g,'')) : null,
    fleet: get("fleet","aircraft","equipment","equip","eqp"),
    seat,
    base: get("base","domicile","dom"),
    status: get("status","category"),
    dob: parseDate(dob),
    doh: parseDate(doh)
  };
}

// ------------------------------ Rates Ingest ------------------------------
function mapRateRow(row){
  // Expect columns: Fleet, Seat, Year, HourlyRate
  const k = n => row[n] ?? row[String(n).toLowerCase()] ?? row[String(n).toUpperCase()];
  const fleet = row.Fleet ?? row.fleet; const seat = normalizeSeat(row.Seat ?? row.seat);
  const year = Number(k("Year")); const rate = Number(k("HourlyRate"));
  if(!fleet || !seat || !year || !rate) return null;
  return { Fleet: String(fleet).trim(), Seat: seat, Year: year, HourlyRate: rate };
}

function getRate(rates, fleet, seat, longevityYear){
  if(!rates || !fleet || !seat || !longevityYear) return undefined;
  const exact = rates.find(r => r.Fleet===fleet && r.Seat===seat && r.Year===longevityYear);
  if (exact) return exact.HourlyRate;
  const series = rates.filter(r => r.Fleet===fleet && r.Seat===seat).sort((a,b)=>a.Year-b.Year);
  if(!series.length) return undefined;
  const last = series[series.length-1];
  return last.HourlyRate; // fallback to top-of-scale if missing
}

// ------------------------------ Retirement + Movement ------------------------------
function buildRetirementCurve(roster, startYear, endYear, fallbackAnnualRatePct){
  const years = {}; for(let y=startYear; y<=endYear; y++) years[y]=0;
  const withDOB = roster.filter(r=>r.dob);
  withDOB.forEach(r=>{ const ry = r.dob.getFullYear()+65; if(ry>=startYear && ry<=endYear) years[ry] += 1; });
  const withoutDOB = roster.length - withDOB.length;
  if (withoutDOB>0 && fallbackAnnualRatePct>0){
    const annual = Math.round(withoutDOB*(fallbackAnnualRatePct/100));
    for(let y=startYear; y<=endYear; y++) years[y]+=annual;
  }
  return Object.entries(years).map(([year,count])=>({year:Number(year), retirements:count}));
}

function simulateMovement({
  rosterSize,
  currentSeniorNumber,
  monthlyAttritionPct,
  monthlyHiring,
  retirementsByYear,
  startYear,
  endYear,
  upgradeThreshold // when aheadRemaining <= threshold, mark upgradeDate
}){
  const months=[]; let dt=new Date(startYear,0,1); const end=new Date(endYear,11,1);
  while(dt<=end){ months.push(new Date(dt)); dt.setMonth(dt.getMonth()+1);}  
  const retireMap = Object.fromEntries(retirementsByYear.map(d=>[d.year,d.retirements]));
  const totalAhead = Math.max(0, currentSeniorNumber-1);
  let ahead = totalAhead; let moved = 0; let upgradeDate=null;
  const series=[];
  months.forEach(m=>{
    const y=m.getFullYear();
    const monthlyR=(retireMap[y]||0)/12;
    const generic=(monthlyAttritionPct/100)*ahead;
    const delta = monthlyR + generic; // hiring doesn't add to ahead of you
    ahead=Math.max(0, ahead-delta);
    moved=totalAhead-ahead;
    const row={month: yyyymm(m), movedAhead:moved, aheadRemaining:ahead};
    if(!upgradeDate && typeof upgradeThreshold==="number" && ahead<=upgradeThreshold){ upgradeDate=row.month; }
    series.push(row);
  });
  return { series, upgradeDate };
}

function project401k({hireDate, startBalance, deferralPct, employerMatchPct, employerMatchCapPct, monthlyCredit, fleet, seat, rates, annualReturn, startYear, endYear, employeeLimit=23000, catchupLimit=7500, age=35}){
  const months=[]; let dt=new Date(startYear,0,1); const end=new Date(endYear,11,1); while(dt<=end){ months.push(new Date(dt)); dt.setMonth(dt.getMonth()+1);}  
  let bal=startBalance||0; const r=Math.pow(1+annualReturn/100,1/12)-1; let ytdEmployee=0; const yearlyLimit=employeeLimit+(age>=50?catchupLimit:0);
  const rows=[];
  months.forEach((m,i)=>{
    if(m.getMonth()===0) ytdEmployee=0;
    const payYear = Math.max(1, (m.getFullYear()-hireDate.getFullYear()) - ((m.getMonth()<hireDate.getMonth()) ? 1:0) + 1);
    const hourly = getRate(rates, fleet, seat, payYear) || 0;
    const monthlyPay = hourly * (monthlyCredit||80);
    const desiredEmp = monthlyPay*(deferralPct/100);
    const emp = Math.min(desiredEmp, Math.max(0, yearlyLimit - ytdEmployee)); ytdEmployee+=emp;
    const matchBase = Math.min(emp, monthlyPay*(employerMatchCapPct/100)); const match = matchBase*(employerMatchPct/100);
    bal = bal*(1+r) + emp + match;
    rows.push({ month: yyyymm(m), balance: Math.round(bal), monthlyPay: Math.round(monthlyPay), hourlyRate: hourly, longevityYear: payYear });
  });
  return rows;
}

// ------------------------------ Simple Self-Tests (dev) ------------------------------
function runSelfTests(){
  const results = [];
  // Test 1: normalizeSeat
  results.push({name: 'normalizeSeat Captain', pass: normalizeSeat('CA')==='Captain'});
  results.push({name: 'normalizeSeat FO', pass: normalizeSeat('fo')==='First Officer'});
  // Test 2: getRate exact & fallback
  const rates = [{Fleet:'A320', Seat:'Captain', Year:1, HourlyRate:200},{Fleet:'A320', Seat:'Captain', Year:2, HourlyRate:210}];
  results.push({name:'getRate exact', pass: getRate(rates,'A320','Captain',2)===210});
  results.push({name:'getRate fallback', pass: getRate(rates,'A320','Captain',5)===210});
  // Test 3: project401k monotonic growth (basic)
  const k = project401k({hireDate:new Date('2025-01-01'),startBalance:0,deferralPct:10,employerMatchPct:5,employerMatchCapPct:5,monthlyCredit:85,fleet:'A320',seat:'Captain',rates:[{Fleet:'A320',Seat:'Captain',Year:1,HourlyRate:200}],annualReturn:0,startYear:2025,endYear:2025});
  const monotonic = k.every((row,i,arr)=> i===0 || row.balance>=arr[i-1].balance);
  results.push({name:'401k monotonic 2025', pass: monotonic});
  // Test 4: simulateMovement aheadRemaining non-increasing
  const mv = simulateMovement({rosterSize:1000,currentSeniorNumber:500,monthlyAttritionPct:0.3,monthlyHiring:100,retirementsByYear:[{year:2025,retirements:120}],startYear:2025,endYear:2025,upgradeThreshold:50}).series;
  const nonInc = mv.every((r,i,a)=> i===0 || r.aheadRemaining <= a[i-1].aheadRemaining);
  results.push({name:'movement ahead non-increasing', pass: nonInc});
  // Test 5: retirement curve sums DOB-driven count
  const rc = buildRetirementCurve([{dob:new Date('1990-01-01')}], 2025, 2054, 0);
  results.push({name:'retirement curve basic', pass: Array.isArray(rc) && rc.length>0});
  // Test 6: roster mapping parses seniority digits
  const m = mapRosterRow({"Seniority Number":"#01234","Seat":"CA"});
  results.push({name:'mapRosterRow seniority numeric', pass: m.senioritynumber===1234 && m.seat==='Captain'});
  // Test 7: upgrade threshold triggers when aheadRemaining <= threshold (system-wide)
  const sim = simulateMovement({
    rosterSize: 10000,
    currentSeniorNumber: 2000,
    monthlyAttritionPct: 0.5,
    monthlyHiring: 0,
    retirementsByYear: [{year:2025,retirements:1200},{year:2026,retirements:1200}],
    startYear: 2025,
    endYear: 2026,
    upgradeThreshold: 100
  });
  const crossed = !!sim.upgradeDate;
  const lastAhead = sim.series[sim.series.length-1]?.aheadRemaining ?? Infinity;
  results.push({name:'upgrade threshold fires (system-wide)', pass: crossed && lastAhead <= 100});

  return results;
}

// ------------------------------ App ------------------------------
export default function App(){
  // Data
  const [roster, setRoster] = useState([]); // all rows
  const [rates, setRates] = useState([]);   // {Fleet, Seat, Year, HourlyRate}

  // Filters
  const [fltFilter, setFltFilter] = useState("ALL");
  const [baseFilter, setBaseFilter] = useState("ALL");
  const [seatFilter, setSeatFilter] = useState("ALL");

  // Scenarios (now with upgrade threshold + hire date + credit hours and target fleet/seat)
  const currentYear = new Date().getFullYear();
  const [scenarios, setScenarios] = useState([
    {
      id: "Baseline",
      currentSeniorNumber: 12000,
      monthlyAttritionPct: 0.30,
      monthlyHiring: 120,
      fallbackAnnualRetirePct: 1.5,
      startYear: currentYear,
      endYear: 2054,
      // Upgrade logic
      upgradeThreshold: 100,               // when <= pilots ahead, call it an upgrade
      targetFleet: "A320",
      targetSeat: "Captain",
      // Comp/401k inputs
      hireDate: new Date(`${currentYear}-03-01`),
      monthlyCredit: 85,
      startBalance: 0,
      deferralPct: 15,
      employerMatchPct: 5,
      employerMatchCapPct: 5,
      annualReturn: 5,
      age: 35
    }
  ]);
  const [activeIDs, setActiveIDs] = useState(["Baseline"]);
  const [testResults, setTestResults] = useState([]);

  // Derived lists for filters
  const fleets = useMemo(()=>Array.from(new Set(roster.map(r=>r.fleet).filter(Boolean))).sort(), [roster]);
  const bases  = useMemo(()=>Array.from(new Set(roster.map(r=>r.base).filter(Boolean))).sort(), [roster]);
  const seats  = ["Captain","First Officer"];

  const filteredRoster = useMemo(()=>{
    return roster.filter(r => (fltFilter==="ALL"||r.fleet===fltFilter) && (baseFilter==="ALL"||r.base===baseFilter) && (seatFilter==="ALL"||r.seat===seatFilter));
  }, [roster, fltFilter, baseFilter, seatFilter]);

  // Retirement curve honors filters
  const retireCurve = useMemo(()=>{
    const rows = filteredRoster.length ? filteredRoster : roster;
    const s = scenarios[0];
    return buildRetirementCurve(rows, s.startYear, s.endYear, s.fallbackAnnualRetirePct);
  }, [filteredRoster, roster, scenarios]);

  // Scenario outputs
  const scenarioOutputs = useMemo(()=>{
    const map = {};
    scenarios.forEach(sc=>{
      const movement = simulateMovement({
        rosterSize: (filteredRoster.length||roster.length||1),
        currentSeniorNumber: sc.currentSeniorNumber,
        monthlyAttritionPct: sc.monthlyAttritionPct,
        monthlyHiring: sc.monthlyHiring,
        retirementsByYear: retireCurve,
        startYear: sc.startYear,
        endYear: sc.endYear,
        upgradeThreshold: sc.upgradeThreshold
      });

      const k = project401k({
        hireDate: sc.hireDate || new Date(`${currentYear}-01-01`),
        startBalance: sc.startBalance,
        deferralPct: sc.deferralPct,
        employerMatchPct: sc.employerMatchPct,
        employerMatchCapPct: sc.employerMatchCapPct,
        monthlyCredit: sc.monthlyCredit,
        fleet: sc.targetFleet,
        seat: sc.targetSeat,
        rates: rates,
        annualReturn: sc.annualReturn,
        startYear: sc.startYear,
        endYear: sc.endYear,
        age: sc.age
      });

      map[sc.id] = { movement: movement.series, upgradeDate: movement.upgradeDate, k };
    });
    return map;
  }, [scenarios, filteredRoster, roster, retireCurve, rates]);

  // ------------------------------ Uploaders ------------------------------
  function handleRosterUpload(e){
    const f = e.target.files?.[0]; if(!f) return;
    const reader = new FileReader();
    reader.onload = evt => {
      const wb = XLSX.read(new Uint8Array(evt.target.result), {type:'array'});
      const pref = ["RosterCurrent","RosterCurrent_Link","Roster","Sheet1"]; const sn = pref.find(n=>wb.Sheets[n]) || wb.SheetNames[0];
      const sheet = wb.Sheets[sn];
      const json = XLSX.utils.sheet_to_json(sheet, {defval:null});
      const rows = json.map(mapRosterRow).filter(r=>r.senioritynumber!=null).sort((a,b)=>a.senioritynumber-b.senioritynumber);
      setRoster(rows);
    };
    reader.readAsArrayBuffer(f);
  }

  function handleRatesUpload(e){
    const f = e.target.files?.[0]; if(!f) return;
    const reader = new FileReader();
    reader.onload = evt => {
      const wb = XLSX.read(new Uint8Array(evt.target.result), {type:'array'});
      const sn = wb.SheetNames.find(n=>/rates/i.test(n)) || wb.SheetNames[0];
      const sheet = wb.Sheets[sn];
      const json = XLSX.utils.sheet_to_json(sheet, {defval:null});
      const rows = json.map(mapRateRow).filter(Boolean);
      setRates(rows);
    };
    reader.readAsArrayBuffer(f);
  }

  // ------------------------------ Scenario controls ------------------------------
  function addScenario(){ const i=scenarios.length+1; const base=scenarios[0]; const copy={...base, id:`Scenario ${i}`, currentSeniorNumber: Math.max(1, base.currentSeniorNumber-500*i)}; setScenarios(s=>[...s, copy]); setActiveIDs(a=>[...a, copy.id]); }
  function cloneScenario(id){ const sc=scenarios.find(x=>x.id===id); if(!sc) return; const copy={...sc, id: sc.id+" Copy"}; setScenarios(s=>[...s, copy]); setActiveIDs(a=>[...a, copy.id]); }
  function updateScenario(id, patch){ setScenarios(s=>s.map(x=>x.id===id?{...x, ...patch}:x)); }

  // ------------------------------ Export ------------------------------
  function downloadCSV(rows, filename){ if(!rows.length) return; const header=Object.keys(rows[0]); const csv=[header.join(",")].concat(rows.map(r=>header.map(h=>JSON.stringify(r[h]??"")).join(","))).join("\\n"); const blob=new Blob([csv],{type:"text/csv"}); const url=URL.createObjectURL(blob); const a=document.createElement("a"); a.href=url; a.download=filename; a.click(); URL.revokeObjectURL(url); }

  const activeScenarios = scenarios.filter(s=>activeIDs.includes(s.id));

  return (
    <div className="min-h-screen bg-gray-50">
      <div className="max-w-7xl mx-auto px-4 py-6">
        <div className="flex items-center justify-between mb-6">
          <div>
            <h1 className="text-2xl font-bold">AA Career Simulator • to 2054</h1>
            <p className="text-gray-600">Compare seniority movement, upgrade timing, and 401(k) outcomes across scenarios.</p>
          </div>
          <div className="flex gap-2">
            <label className="inline-flex items-center gap-2 px-3 py-2 rounded-xl bg-blue-600 text-white cursor-pointer hover:bg-blue-700">
              <Upload className="w-4 h-4"/>
              <span>Upload roster (.xlsx)</span>
              <input type="file" accept=".xlsx,.xls,.csv" className="hidden" onChange={handleRosterUpload}/>
            </label>
            <label className="inline-flex items-center gap-2 px-3 py-2 rounded-xl bg-emerald-600 text-white cursor-pointer hover:bg-emerald-700">
              <Upload className="w-4 h-4"/>
              <span>Upload pay Rates (.xlsx)</span>
              <input type="file" accept=".xlsx,.xls,.csv" className="hidden" onChange={handleRatesUpload}/>
            </label>
            <button className="px-3 py-2 rounded-xl bg-gray-200 hover:bg-gray-300" onClick={addScenario}><Plus className="w-4 h-4 inline mr-1"/>Add scenario</button>
          </div>
        </div>

        {/* Filters */}
        <Card className="mb-6">
          <SectionTitle icon={Filter}>Filters (apply to retirements & movement base size)</SectionTitle>
          <div className="grid md:grid-cols-3 gap-3 text-sm">
            <label className="flex flex-col">Fleet
              <select className="mt-1 rounded-lg border px-2 py-1" value={fltFilter} onChange={e=>setFltFilter(e.target.value)}>
                <option>ALL</option>{fleets.map(f=><option key={f}>{f}</option>)}
              </select>
            </label>
            <label className="flex flex-col">Base
              <select className="mt-1 rounded-lg border px-2 py-1" value={baseFilter} onChange={e=>setBaseFilter(e.target.value)}>
                <option>ALL</option>{bases.map(b=><option key={b}>{b}</option>)}
              </select>
            </label>
            <label className="flex flex-col">Seat
              <select className="mt-1 rounded-lg border px-2 py-1" value={seatFilter} onChange={e=>setSeatFilter(e.target.value)}>
                <option>ALL</option>{seats.map(s=><option key={s}>{s}</option>)}
              </select>
            </label>
          </div>
        </Card>

        {/* Scenario Cards */}
        <div className="grid md:grid-cols-2 xl:grid-cols-3 gap-4 mb-6">
          {scenarios.map(sc=> (
            <Card key={sc.id}>
              <div className="flex items-center justify-between">
                <h3 className="font-semibold">{sc.id}</h3>
                <div className="flex items-center gap-2">
                  <button className="text-sm px-2 py-1 bg-gray-100 rounded" onClick={()=>cloneScenario(sc.id)}><Copy className="w-3 h-3 inline mr-1"/>Clone</button>
                  <label className="flex items-center gap-1 text-sm"><input type="checkbox" className="accent-blue-600" checked={activeIDs.includes(sc.id)} onChange={(e)=>{ const on=e.target.checked; setActiveIDs(p=> on? [...new Set([...p, sc.id])] : p.filter(x=>x!==sc.id)); }} /> Active</label>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-2 mt-3 text-sm">
                <label className="flex flex-col">Your Seniority #
                  <input className="mt-1 rounded-lg border px-2 py-1" type="number" value={sc.currentSeniorNumber} onChange={e=>updateScenario(sc.id,{currentSeniorNumber:Number(e.target.value)})}/>
                </label>
                <label className="flex flex-col">Upgrade Threshold (ahead <=)
                  <input className="mt-1 rounded-lg border px-2 py-1" type="number" value={sc.upgradeThreshold} onChange={e=>updateScenario(sc.id,{upgradeThreshold:Number(e.target.value)})}/>
                </label>
                <label className="flex flex-col">Monthly Attrition %
                  <input className="mt-1 rounded-lg border px-2 py-1" type="number" step="0.01" value={sc.monthlyAttritionPct} onChange={e=>updateScenario(sc.id,{monthlyAttritionPct:Number(e.target.value)})}/>
                </label>
                <label className="flex flex-col">Monthly Hiring
                  <input className="mt-1 rounded-lg border px-2 py-1" type="number" value={sc.monthlyHiring} onChange={e=>updateScenario(sc.id,{monthlyHiring:Number(e.target.value)})}/>
                </label>
                <label className="flex flex-col">Start Year
                  <input className="mt-1 rounded-lg border px-2 py-1" type="number" value={sc.startYear} onChange={e=>updateScenario(sc.id,{startYear:Number(e.target.value)})}/>
                </label>
                <label className="flex flex-col">End Year (≤2054)
                  <input className="mt-1 rounded-lg border px-2 py-1" type="number" value={sc.endYear} onChange={e=>updateScenario(sc.id,{endYear:Number(e.target.value)})}/>
                </label>
              </div>

              <div className="border-t my-3" />

              <div className="grid grid-cols-2 gap-2 text-sm">
                <label className="flex flex-col">Hire Date
                  <input className="mt-1 rounded-lg border px-2 py-1" type="date" value={sc.hireDate ? new Date(sc.hireDate).toISOString().slice(0,10) : ""} onChange={e=>updateScenario(sc.id,{hireDate: new Date(e.target.value)})}/>
                </label>
                <label className="flex flex-col">Monthly Credit Hrs
                  <input className="mt-1 rounded-lg border px-2 py-1" type="number" value={sc.monthlyCredit} onChange={e=>updateScenario(sc.id,{monthlyCredit:Number(e.target.value)})}/>
                </label>
                <label className="flex flex-col">Target Fleet
                  <input className="mt-1 rounded-lg border px-2 py-1" value={sc.targetFleet} onChange={e=>updateScenario(sc.id,{targetFleet:e.target.value})}/>
                </label>
                <label className="flex flex-col">Target Seat
                  <select className="mt-1 rounded-lg border px-2 py-1" value={sc.targetSeat} onChange={e=>updateScenario(sc.id,{targetSeat:e.target.value})}>
                    <option>Captain</option>
                    <option>First Officer</option>
                  </select>
                </label>
              </div>

              <div className="border-t my-3" />

              <div className="grid grid-cols-2 gap-2 text-sm">
                <label className="flex flex-col">401k Start Balance
                  <input className="mt-1 rounded-lg border px-2 py-1" type="number" value={sc.startBalance} onChange={e=>updateScenario(sc.id,{startBalance:Number(e.target.value)})}/>
                </label>
                <label className="flex flex-col">Deferral %
                  <input className="mt-1 rounded-lg border px-2 py-1" type="number" step="0.1" value={sc.deferralPct} onChange={e=>updateScenario(sc.id,{deferralPct:Number(e.target.value)})}/>
                </label>
                <label className="flex flex-col">Match %
                  <input className="mt-1 rounded-lg border px-2 py-1" type="number" step="0.1" value={sc.employerMatchPct} onChange={e=>updateScenario(sc.id,{employerMatchPct:Number(e.target.value)})}/>
                </label>
                <label className="flex flex-col">Match Cap %
                  <input className="mt-1 rounded-lg border px-2 py-1" type="number" step="0.1" value={sc.employerMatchCapPct} onChange={e=>updateScenario(sc.id,{employerMatchCapPct:Number(e.target.value)})}/>
                </label>
                <label className="flex flex-col">Annual Return %
                  <input className="mt-1 rounded-lg border px-2 py-1" type="number" step="0.1" value={sc.annualReturn} onChange={e=>updateScenario(sc.id,{annualReturn:Number(e.target.value)})}/>
                </label>
                <label className="flex flex-col">Age (for catch-up)
                  <input className="mt-1 rounded-lg border px-2 py-1" type="number" value={sc.age} onChange={e=>updateScenario(sc.id,{age:Number(e.target.value)})}/>
                </label>
              </div>
            </Card>
          ))}
        </div>

        {/* Charts */}
        <div className="grid md:grid-cols-2 gap-4">
          <Card>
            <SectionTitle icon={Rocket} right={<span className="text-sm text-gray-500">Shows when you cross Upgrade Threshold</span>}>
              Projected Seniority Movement
            </SectionTitle>
            <div className="h-72">
              <ResponsiveContainer width="100%" height="100%">
                <LineChart>
                  <CartesianGrid strokeDasharray="3 3" />
                  <XAxis dataKey="month" allowDuplicatedCategory={false} />
                  <YAxis />
                  <Tooltip />
                  <Legend />
                  {activeScenarios.map(sc => (
                    <Line key={sc.id} type="monotone" name={`${sc.id} (ahead)`} data={scenarioOutputs[sc.id]?.movement} dataKey="aheadRemaining" dot={false} />
                  ))}
                </LineChart>
              </ResponsiveContainer>
            </div>
          </Card>

          <Card>
            <SectionTitle icon={Database}>401(k) Balance Projection (with real rates if loaded)</SectionTitle>
            <div className="h-72">
              <ResponsiveContainer width="100%" height="100%">
                <LineChart>
                  <CartesianGrid strokeDasharray="3 3" />
                  <XAxis dataKey="month" allowDuplicatedCategory={false} />
                  <YAxis />
                  <Tooltip />
                  <Legend />
                  {activeScenarios.map(sc => (
                    <Line key={sc.id} type="monotone" name={`${sc.id} (balance)`} data={scenarioOutputs[sc.id]?.k} dataKey="balance" dot={false} />
                  ))}
                </LineChart>
              </ResponsiveContainer>
            </div>
          </Card>
        </div>

        {/* Retirement histogram */}
        <div className="mt-4 grid md:grid-cols-2 gap-4">
          <Card>
            <SectionTitle icon={Database}>Annual Retirements (filtered roster)</SectionTitle>
            <div className="h-64">
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={retireCurve}>
                  <CartesianGrid strokeDasharray="3 3" />
                  <XAxis dataKey="year" />
                  <YAxis />
                  <Tooltip />
                  <Legend />
                  <Bar dataKey="retirements" name="Retirements" />
                </BarChart>
              </ResponsiveContainer>
            </div>
          </Card>

          <Card>
            <SectionTitle icon={Settings}>Scenario Snapshot (last month)</SectionTitle>
            <div className="overflow-auto max-h-64 text-sm">
              <table className="w-full">
                <thead className="sticky top-0 bg-gray-100">
                  <tr>
                    <th className="text-left p-2">Scenario</th>
                    <th className="text-left p-2">Ahead Remaining</th>
                    <th className="text-left p-2">Upgrade Date</th>
                    <th className="text-left p-2">Last Hourly</th>
                    <th className="text-left p-2">401k Balance</th>
                  </tr>
                </thead>
                <tbody>
                  {activeScenarios.map(sc => {
                    const move = scenarioOutputs[sc.id]?.movement || [];
                    const k = scenarioOutputs[sc.id]?.k || [];
                    const lastMove = move[move.length - 1];
                    const lastK = k[k.length - 1];
                    return (
                      <tr key={sc.id} className="border-t">
                        <td className="p-2">{sc.id}</td>
                        <td className="p-2">{lastMove ? Math.round(lastMove.aheadRemaining).toLocaleString() : "-"}</td>
                        <td className="p-2">{scenarioOutputs[sc.id]?.upgradeDate || "—"}</td>
                        <td className="p-2">{lastK ? `$${Number(lastK.hourlyRate || 0).toFixed(0)}` : "-"}</td>
                        <td className="p-2">{lastK ? `$${Number(lastK.balance).toLocaleString()}` : "-"}</td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          </Card>
        </div>

        {/* Data export */}
        <div className="mt-6">
          <Card>
            <SectionTitle icon={Download}>Export scenario data</SectionTitle>
            <div className="flex flex-wrap gap-2 mt-2">
              {activeScenarios.map(sc => (
                <div key={sc.id} className="flex gap-2">
                  <button className="px-3 py-2 rounded-lg bg-gray-100 hover:bg-gray-200" onClick={() => {
                    const rows = (scenarioOutputs[sc.id]?.movement || []).map(r => ({ scenario: sc.id, ...r }));
                    if (rows.length) downloadCSV(rows, `${sc.id.replace(/\\s+/g,'_')}_movement.csv`);
                  }}>Download {sc.id} movement CSV</button>
                  <button className="px-3 py-2 rounded-lg bg-gray-100 hover:bg-gray-200" onClick={() => {
                    const rows = (scenarioOutputs[sc.id]?.k || []).map(r => ({ scenario: sc.id, ...r }));
                    if (rows.length) downloadCSV(rows, `${sc.id.replace(/\\s+/g,'_')}_401k.csv`);
                  }}>Download {sc.id} 401k CSV</button>
                </div>
              ))}
            </div>
            <div className="text-xs text-gray-500 mt-3">Tip: upload your merged roster (<strong>AA_Seniority_Master.xlsx</strong>) and your pay table (sheet name containing <em>Rates</em> with columns Fleet, Seat, Year, HourlyRate).</div>
          </Card>
        </div>

        {/* Dev Self-Tests */}
        <div className="mt-6">
          <Card>
            <SectionTitle icon={Settings} right={<button className="text-sm px-3 py-1 bg-gray-100 rounded" onClick={()=>setTestResults(runSelfTests())}>Run self-tests</button>}>
              Developer Self-Tests
            </SectionTitle>
            <div className="text-sm">
              {testResults.length === 0 && (
                <p className="text-gray-500">Click the button to run quick sanity checks for helpers and 401(k) projection.</p>
              )}
              {testResults.length > 0 && (
                <ul className="list-disc pl-5">
                  {testResults.map((t, i) => (
                    <li key={i} className={t.pass ? "text-emerald-700" : "text-red-600"}>
                      {t.pass ? "PASS" : "FAIL"} — {t.name}
                    </li>
                  ))}
                </ul>
              )}
            </div>
          </Card>
        </div>

        <div className="mt-8 text-xs text-gray-500">
          <p>
            Model notes: Upgrade timing shown when pilots ahead ≤ threshold. Retirement curve uses DOB→65 when available; otherwise applies your fallback annual percentage to the non-DOB population. 401(k) uses uploaded pay rates by Fleet/Seat/Longevity Year × Monthly Credit. Validate against your CBA and plan documents.
          </p>
        </div>
      </div>
    </div>
  );
}
